--
-- PostgreSQL database dump
--

\restrict GEZCo8hDF597RE4KPs4df0X0ygLSSG9kjcwoAN52eRjpNAt3OAOPNmo0yv6bTuE

-- Dumped from database version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bodega_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bodega_records (
    id integer NOT NULL,
    record_code character varying(20),
    telegram_user_id bigint NOT NULL,
    record_type character varying(20) NOT NULL,
    product character varying(150),
    weight_kg numeric(8,3),
    unit character varying(20),
    quantity integer,
    supplier_id integer,
    supplier_name character varying(100),
    location_id integer,
    location_name character varying(100),
    requirement_id integer,
    file_id text,
    notes text,
    status character varying(20) DEFAULT 'ok'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    correction_of integer,
    correction_reason text,
    is_corrected boolean DEFAULT false,
    lot_id integer,
    lot_code character varying(50)
);


--
-- Name: bodega_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bodega_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bodega_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bodega_records_id_seq OWNED BY public.bodega_records.id;


--
-- Name: bodega_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bodega_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(20) NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lots (
    id integer NOT NULL,
    lot_code character varying(50) NOT NULL,
    product_prefix character varying(10) NOT NULL,
    product_name character varying(150) NOT NULL,
    lot_source character varying(20) DEFAULT 'generado'::character varying,
    initial_weight numeric(8,3),
    initial_unit character varying(20),
    current_weight numeric(8,3),
    supplier_name character varying(100),
    status character varying(20) DEFAULT 'activo'::character varying,
    created_by bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    closed_at timestamp without time zone,
    closed_by bigint
);


--
-- Name: lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lots_id_seq OWNED BY public.lots.id;


--
-- Name: media_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media_groups (
    id integer NOT NULL,
    media_group_id character varying(50) NOT NULL,
    record_id integer,
    record_table character varying(20),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: media_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.media_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.media_groups_id_seq OWNED BY public.media_groups.id;


--
-- Name: record_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.record_photos (
    id integer NOT NULL,
    record_id integer NOT NULL,
    record_table character varying(20) NOT NULL,
    file_id text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: record_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.record_photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: record_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.record_photos_id_seq OWNED BY public.record_photos.id;


--
-- Name: record_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.record_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.records (
    id integer NOT NULL,
    record_code character varying(20),
    telegram_user_id bigint NOT NULL,
    record_type character varying(20) NOT NULL,
    product character varying(150),
    weight_kg numeric(8,3),
    unit character varying(20),
    quantity integer,
    destination character varying(100),
    supplier character varying(100),
    file_id text,
    notes text,
    status character varying(20) DEFAULT 'ok'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    correction_of integer,
    correction_reason text,
    is_corrected boolean DEFAULT false,
    lot_id integer,
    lot_code character varying(50)
);


--
-- Name: records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.records_id_seq OWNED BY public.records.id;


--
-- Name: req_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.req_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: requirements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.requirements (
    id integer NOT NULL,
    req_code character varying(20),
    location_id integer,
    status character varying(20) DEFAULT 'pendiente'::character varying,
    notes text,
    received_at timestamp without time zone DEFAULT now(),
    dispatched_at timestamp without time zone
);


--
-- Name: requirements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.requirements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: requirements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.requirements_id_seq OWNED BY public.requirements.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    contact character varying(100),
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: ticket_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ticket_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tickets (
    id integer NOT NULL,
    ticket_code character varying(20),
    record_id integer,
    ticket_type character varying(30),
    description text NOT NULL,
    reported_by bigint NOT NULL,
    supplier character varying(100),
    status character varying(20) DEFAULT 'abierto'::character varying,
    opened_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone
);


--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    role character varying(20) DEFAULT 'staff'::character varying NOT NULL,
    area character varying(50),
    local character varying(50),
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    removed_at timestamp without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: bodega_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodega_records ALTER COLUMN id SET DEFAULT nextval('public.bodega_records_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lots ALTER COLUMN id SET DEFAULT nextval('public.lots_id_seq'::regclass);


--
-- Name: media_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_groups ALTER COLUMN id SET DEFAULT nextval('public.media_groups_id_seq'::regclass);


--
-- Name: record_photos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_photos ALTER COLUMN id SET DEFAULT nextval('public.record_photos_id_seq'::regclass);


--
-- Name: records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.records ALTER COLUMN id SET DEFAULT nextval('public.records_id_seq'::regclass);


--
-- Name: requirements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirements ALTER COLUMN id SET DEFAULT nextval('public.requirements_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: bodega_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bodega_records (id, record_code, telegram_user_id, record_type, product, weight_kg, unit, quantity, supplier_id, supplier_name, location_id, location_name, requirement_id, file_id, notes, status, created_at, correction_of, correction_reason, is_corrected, lot_id, lot_code) FROM stdin;
2	DSP-0002	216920595	despacho	Despacho aceite 12lt	12.000	lt	\N	\N	\N	\N	Isla Portela	\N	AgACAgEAAxkBAAMQaknezQhfkQdme9ch0fFMnT7nI4kAAp0MaxsVtVFGe9UzvKD8AAHtAQADAgADeQADPAQ	Despacho aceite 12lt	ok	2026-07-05 04:34:25.505821	\N	\N	f	\N	\N
3	DSP-0003	216920595	despacho	Despacho aceite 12lt	12.000	lt	\N	\N	\N	\N	Isla Portela	\N	AgACAgEAAxkBAAMSaknfMeN39-LBiBvrIq_t1psNg20AAp4MaxsVtVFGT-y3ZRA86DABAAMCAAN5AAM8BA	Despacho aceite 12lt	ok	2026-07-05 04:36:42.23798	\N	\N	f	\N	\N
4	ING-0004	216920595	ingreso	Ingresa pollo Pronaca 45kg	45.000	kg	\N	\N	Pronaca	\N	\N	\N	AgACAgEAAxkBAAMUaknfzbpvYnruSIkzccDpedj9-7gAAp8MaxsVtVFGYyCyoM1U7kgBAAMCAAN5AAM8BA	Ingresa pollo Pronaca 45kg	ok	2026-07-05 04:38:37.522598	\N	\N	f	\N	\N
5	ING-0005	216920595	ingreso	Ingresa pollo Pronaca 45kg	45.000	kg	\N	\N	Pronaca	\N	\N	\N	AgACAgEAAxkBAAMdaknk-g3NO97ROA_XFKfJwhn8n6MAAvALaxt__FBGS8qilqg34d4BAAMCAAN5AAM8BA	Ingresa pollo Pronaca 45kg	ok	2026-07-05 05:00:42.961475	\N	\N	f	\N	\N
6	ING-0006	216920595	ingreso	Ingresa pollo Pronaca 45kg	45.000	kg	\N	\N	Pronaca	\N	\N	\N	AgACAgEAAxkBAAMfaknlPqxnCoUTYZ2dCtrcmnro7DAAAvILaxt__FBGYqxs1XKZv5kBAAMCAAN5AAM8BA	Ingresa pollo Pronaca 45kg	ok	2026-07-05 05:01:50.783532	\N	\N	f	\N	\N
7	ING-0007	216920595	ingreso	Ingresa camisas Pronaca 45kg	45.000	kg	\N	\N	Pronaca	\N	\N	\N	AgACAgEAAxkBAAMSaknfMeN39-LBiBvrIq_t1psNg20AAp4MaxsVtVFGT-y3ZRA86DABAAMCAAN5AAM8BA	Ingresa camisas Pronaca 45kg	ok	2026-07-05 05:02:24.458707	\N	\N	f	\N	\N
8	ING-0008	216920595	ingreso	ingresa camisas pronaca 34kg	34.000	kg	\N	\N	Pronaca	\N	\N	\N	AgACAgEAAxkBAAMSaknfMeN39-LBiBvrIq_t1psNg20AAp4MaxsVtVFGT-y3ZRA86DABAAMCAAN5AAM8BA	ingresa camisas pronaca 34kg	ok	2026-07-05 05:08:31.358997	\N	\N	f	\N	\N
9	ING-0009	216920595	ingreso	ingreso de pulpa de cangrejo 87kg	87.000	kg	\N	\N	Victor Peñuela	\N	\N	\N	AgACAgEAAxkBAAM3aknoh_K68IZHO4kNvB2P-E2tFGMAAvULaxt__FBGYMBEmaMMfOUBAAMCAAN5AAM8BA	ingreso de pulpa de cangrejo 87kg	ok	2026-07-05 05:16:03.477233	\N	\N	f	\N	\N
13	ING-0012-C1	216920595	ingreso	ingresan camaras 456kg	32.000	kg	\N	\N	Alex	\N	\N	\N	AgACAgEAAxkBAANZaknq4lvmCsIXrvt4YF9sKCuCv8YAAvcLaxt__FBG_LggGW2t1twBAAMCAAN5AAM8BA	ing-0012 32kg	corregido	2026-07-05 05:28:20.594419	12	Peso corregido: 456.000 kg a 32.0 kg	t	\N	\N
14	ING-0012-C2	216920595	ingreso	ingresan camaras 456kg	32.000	kg	\N	\N	Alex	\N	\N	\N	AgACAgEAAxkBAANZaknq4lvmCsIXrvt4YF9sKCuCv8YAAvcLaxt__FBG_LggGW2t1twBAAMCAAN5AAM8BA	ing-0012 32kg	activo	2026-07-05 05:28:28.411285	13	Peso corregido: 32.000 kg a 32.0 kg	f	\N	\N
15	ING-0013	216920595	ingreso	Ingreso de camarón	123.000	kg	\N	\N	Jacinto	\N	\N	\N	AgACAgEAAxkBAANiakqEeNm5KEtQTODc3C4kmfCmu1UAAlIMaxt__FhGL7Nq0orJHK8BAAMCAAN5AAM8BA	Ingreso de camarón	ok	2026-07-05 16:21:24.23697	\N	\N	f	\N	\N
16	ING-0014	216920595	ingreso	Ingreso camarón	34.000	kg	\N	\N	Joaquín	\N	\N	\N	AgACAgEAAxkBAANuaksnZE_HBHyuYAZoO-ZrOz392hcAArQLaxsVtWFG4rOuEF9ViT8BAAMCAAN5AAM8BA	Ingreso camarón	ok	2026-07-06 03:56:34.292218	\N	\N	f	\N	\N
10	ING-0010	216920595	ingreso	ingresa cangrejos 34kg	34.000	kg	\N	\N	Teodoro	\N	\N	\N	AgACAgEAAxkBAANCaknpRlYjJ6hTF8HR5Wusdnt7GH4AAvYLaxt__FBGw3HVbjCweAUBAAMCAAN5AAM8BA	ingresa cangrejos 34kg	ok	2026-07-05 05:19:07.292248	\N	\N	f	\N	\N
1	ING-0001	216920595	ingreso	Ingresa pollo Pronaca 45kg	45.000	kg	\N	\N	Pronaca	\N	\N	\N	AgACAgEAAxkBAAMLakneDN0lrTOZHUAqgXYuR2CpNW4AApwMaxsVtVFGnpjAHLYWlesBAAMCAAN5AAM8BA	Ingresa pollo Pronaca 45kg	corregido	2026-07-05 04:33:00.804122	\N	\N	t	\N	\N
17	ING-0001-C1	216920595	ingreso	Ingresa pollo Pronaca 45kg	13.000	kg	\N	\N	Pronaca	\N	\N	\N	AgACAgEAAxkBAAMLakneDN0lrTOZHUAqgXYuR2CpNW4AApwMaxsVtVFGnpjAHLYWlesBAAMCAAN5AAM8BA	13kg	activo	2026-07-07 03:40:49.742977	1	Peso corregido: 45.000 kg a 13.0 kg	f	\N	\N
18	ING-0015	216920595	ingreso	Ingresa camarón 45kg	45.000	kg	\N	\N	Rimero	\N	\N	\N	AgACAgEAAyEFAAMBAAFvZL0AAwVqTnO6UODkkkJWSOsD_aKJNbt71wAC2RBrGys2eEba5n272YPfgAEAAwIAA3kAAzwE	Ingresa camarón 45kg	ok	2026-07-08 15:58:56.277451	\N	\N	f	\N	\N
19	ING-0016	7312738927	ingreso	Ingresa camaron con 456kg	456.000	kg	\N	\N	Erika	\N	\N	\N	AgACAgEAAyEFAAMBAAFvZL0AAwlqTnQj1cDvpjbrKq2_Kh432dbA4AAC2hBrGys2eEZg4_7ET2iR5gEAAwIAA3kAAzwE	Ingresa camaron con 456kg	ok	2026-07-08 16:00:41.626545	\N	\N	f	\N	\N
20	ING-0017	5228839747	ingreso	Ingresa pulpa de cangrejo 7.02 kg	7.020	kg	\N	\N	Dario	\N	\N	\N	AgACAgEAAyEFAAMBAAFvZL0AAw5qTnbCP6IMw-Ff-kn2_FPiaXD2lAAC3RBrGys2eEYzcPxso1B6oAEAAwIAA3kAAzwE	Ingresa pulpa de cangrejo 7.02 kg	ok	2026-07-08 16:12:01.842229	\N	\N	f	\N	\N
21	ING-0018	5228839747	ingreso	Ingresa papas fritas 62.5 kg	62.500	kg	\N	\N	Mccain	\N	\N	\N	AgACAgEAAyEFAAMBAAFvZL0AAxlqTo41CHKi2OWGIu4e71FlAngfsAAC9hBrGys2eEa-GLDDm8QRtwEAAwIAA3kAAzwE	Ingresa papas fritas 62.5 kg	ok	2026-07-08 17:54:07.441028	\N	\N	f	\N	\N
22	ING-0019	216920595	ingreso	Ingresa camarón 254 kg	254.000	kg	\N	\N	Expotuna	\N	\N	\N	AgACAgEAAxkBAAN-ak6rNrbF3L5TTZib_UMxLBumvq4AAscPaxtMbnlG-3zA3K9M4WIBAAMCAAN5AAM8BA	Ingresa camarón 254 kg	ok	2026-07-08 19:55:52.3862	\N	\N	f	\N	\N
23	ING-0020	216920595	ingreso	Ingresa camarón 45kg	45.000	kg	\N	\N	Danny	\N	\N	\N	AgACAgEAAxkBAAOCak76jgP6Q2DLEeHWv8TiU6oBU3sAAtkPaxtMbnlGW8hGQwR-O6EBAAMCAAN5AAM8BA	Ingresa camarón 45kg	ok	2026-07-09 01:34:13.849853	\N	\N	f	\N	\N
24	ING-0021	5228839747	ingreso	Ingresa pulpa de cangrejo  3.11 kg \nProovedor	3.110	kg	\N	\N	Walter	\N	\N	\N	AgACAgEAAyEFAAMBAAFvZL0AAx1qT6YplwQNLe6Wz57WA_5_rbm8BgACRQxrG3LrgEbUM1sfaPOd3QEAAwIAA3kAAzwE	Ingresa pulpa de cangrejo  3.11 kg \nProovedor	ok	2026-07-09 14:17:58.419178	\N	\N	f	\N	\N
25	ING-0022	5228839747	ingreso	Ingresa uñas de cangrejo 582 und\nProovedor Darío	582.000	und	\N	\N	Walter	\N	\N	\N	AgACAgEAAyEFAAMBAAFvZL0AAyFqT8bzJlW5UcspQcAUOE-DamMiEQACVgxrG3LrgEZpKOdp3B1GGwEAAwIAA3kAAzwE	Ingresa uñas de cangrejo 582 und\nProovedor Darío	ok	2026-07-09 20:42:50.783883	\N	\N	f	\N	\N
11	ING-0011	216920595	ingreso	ingresan pera 34kg	34.000	kg	\N	\N	fruteria	\N	\N	\N	AgACAgEAAxkBAAMSaknfMeN39-LBiBvrIq_t1psNg20AAp4MaxsVtVFGT-y3ZRA86DABAAMCAAN5AAM8BA	ingresan pera 34kg	ok	2026-07-05 05:25:19.857497	\N	\N	f	\N	\N
26	ING-0023	5228839747	ingreso	Ingresa costillas 42 pax + 1 und\nProovedor : Don Curi	1.000	und	\N	\N	Don Curi	\N	\N	\N	AgACAgEAAyEFAAMBAAFvZL0AAypqUAgZJ24o3x2oL40l8eS0JbC4owACbAxrG3LrgEYaCE2KQHiZOwEAAwIAA3kAAzwE	Ingresa costillas 42 pax + 1 und\nProovedor : Don Curi	ok	2026-07-09 20:44:27.968615	\N	\N	f	\N	\N
27	ING-0024	5228839747	ingreso	Ingresa queso parmezano 4 und\nCrema de leche 10 tachos\nProveedor Alpina	4.000	und	\N	\N	Proveedor alpina	\N	\N	\N	AgACAgEAAyEFAAMBAAFvZL0AAy9qUAh4Um2GYQcSdwnX4mw0TwozxwACbgxrG3LrgEbOqhuYeD7fGgEAAwIAA3kAAzwE	Ingresa queso parmezano 4 und\nCrema de leche 10 tachos\nProveedor Alpina	ok	2026-07-09 20:45:46.073543	\N	\N	f	\N	\N
12	ING-0012	216920595	ingreso	ingresan camaras 456kg	456.000	kg	\N	\N	Alex	\N	\N	\N	AgACAgEAAxkBAANZaknq4lvmCsIXrvt4YF9sKCuCv8YAAvcLaxt__FBG_LggGW2t1twBAAMCAAN5AAM8BA	ingresan camaras 456kg	corregido	2026-07-05 05:25:57.21649	\N	\N	t	\N	\N
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.locations (id, name, code, active) FROM stdin;
1	Mall del Sol	MLS	t
2	San Marino	SMR	t
3	Plaza Batán	BTN	t
4	Village Plaza	VLG	t
5	Puerto Santa Ana	PSA	t
6	Isla Portela	IPT	t
7	Ceibos	CBO	t
\.


--
-- Data for Name: lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lots (id, lot_code, product_prefix, product_name, lot_source, initial_weight, initial_unit, current_weight, supplier_name, status, created_by, created_at, closed_at, closed_by) FROM stdin;
\.


--
-- Data for Name: media_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media_groups (id, media_group_id, record_id, record_table, created_at) FROM stdin;
\.


--
-- Data for Name: record_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.record_photos (id, record_id, record_table, file_id, created_at) FROM stdin;
\.


--
-- Data for Name: records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.records (id, record_code, telegram_user_id, record_type, product, weight_kg, unit, quantity, destination, supplier, file_id, notes, status, created_at, correction_of, correction_reason, is_corrected, lot_id, lot_code) FROM stdin;
1	POR-0001	216920595	porcionado	Camarón	45.000	kg	\N	\N	\N	AgACAgEAAxkBAAP1akwB0GzdPAAB_zmuLhX1qrZ6gH5gAAJqDGsbXD5hRpaxighNBLuGAQADAgADeQADPAQ	Camarón	ok	2026-07-06 19:28:39.94375	\N	\N	f	\N	\N
\.


--
-- Data for Name: requirements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.requirements (id, req_code, location_id, status, notes, received_at, dispatched_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, contact, active, created_at) FROM stdin;
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tickets (id, ticket_code, record_id, ticket_type, description, reported_by, supplier, status, opened_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, telegram_id, name, role, area, local, active, created_at, removed_at) FROM stdin;
1	216920595	Alex Criollo Leiva	superadmin	\N	\N	t	2026-07-04 03:40:41.96706	\N
3	7312738927	Ing. Mónica Valente	admin	produccion,bodega	\N	t	2026-07-08 15:56:11.540881	\N
4	5228839747	Jostin Muñoz	staff	\N	\N	t	2026-07-08 16:10:26.276391	\N
\.


--
-- Name: bodega_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bodega_records_id_seq', 27, true);


--
-- Name: bodega_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bodega_seq', 24, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.locations_id_seq', 7, true);


--
-- Name: lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lots_id_seq', 1, false);


--
-- Name: media_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.media_groups_id_seq', 1, false);


--
-- Name: record_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.record_photos_id_seq', 1, false);


--
-- Name: record_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.record_seq', 1, true);


--
-- Name: records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.records_id_seq', 1, true);


--
-- Name: req_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.req_seq', 1, false);


--
-- Name: requirements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.requirements_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, false);


--
-- Name: ticket_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ticket_seq', 1, false);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tickets_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: bodega_records bodega_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodega_records
    ADD CONSTRAINT bodega_records_pkey PRIMARY KEY (id);


--
-- Name: bodega_records bodega_records_record_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodega_records
    ADD CONSTRAINT bodega_records_record_code_key UNIQUE (record_code);


--
-- Name: locations locations_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_code_key UNIQUE (code);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: lots lots_lot_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT lots_lot_code_key UNIQUE (lot_code);


--
-- Name: lots lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT lots_pkey PRIMARY KEY (id);


--
-- Name: media_groups media_groups_media_group_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_groups
    ADD CONSTRAINT media_groups_media_group_id_key UNIQUE (media_group_id);


--
-- Name: media_groups media_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_groups
    ADD CONSTRAINT media_groups_pkey PRIMARY KEY (id);


--
-- Name: record_photos record_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_photos
    ADD CONSTRAINT record_photos_pkey PRIMARY KEY (id);


--
-- Name: records records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.records
    ADD CONSTRAINT records_pkey PRIMARY KEY (id);


--
-- Name: records records_record_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.records
    ADD CONSTRAINT records_record_code_key UNIQUE (record_code);


--
-- Name: requirements requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirements
    ADD CONSTRAINT requirements_pkey PRIMARY KEY (id);


--
-- Name: requirements requirements_req_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirements
    ADD CONSTRAINT requirements_req_code_key UNIQUE (req_code);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_ticket_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_ticket_code_key UNIQUE (ticket_code);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: bodega_records bodega_records_correction_of_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodega_records
    ADD CONSTRAINT bodega_records_correction_of_fkey FOREIGN KEY (correction_of) REFERENCES public.bodega_records(id);


--
-- Name: bodega_records bodega_records_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodega_records
    ADD CONSTRAINT bodega_records_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: bodega_records bodega_records_requirement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodega_records
    ADD CONSTRAINT bodega_records_requirement_id_fkey FOREIGN KEY (requirement_id) REFERENCES public.requirements(id);


--
-- Name: bodega_records bodega_records_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bodega_records
    ADD CONSTRAINT bodega_records_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: records records_correction_of_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.records
    ADD CONSTRAINT records_correction_of_fkey FOREIGN KEY (correction_of) REFERENCES public.records(id);


--
-- Name: requirements requirements_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirements
    ADD CONSTRAINT requirements_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: tickets tickets_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_record_id_fkey FOREIGN KEY (record_id) REFERENCES public.records(id);


--
-- Name: TABLE bodega_records; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.bodega_records TO pepepez;


--
-- Name: SEQUENCE bodega_records_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.bodega_records_id_seq TO pepepez;


--
-- Name: SEQUENCE bodega_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.bodega_seq TO pepepez;


--
-- Name: TABLE locations; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.locations TO pepepez;


--
-- Name: SEQUENCE locations_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.locations_id_seq TO pepepez;


--
-- Name: TABLE lots; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.lots TO pepepez;


--
-- Name: SEQUENCE lots_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.lots_id_seq TO pepepez;


--
-- Name: TABLE media_groups; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.media_groups TO pepepez;


--
-- Name: SEQUENCE media_groups_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.media_groups_id_seq TO pepepez;


--
-- Name: TABLE record_photos; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.record_photos TO pepepez;


--
-- Name: SEQUENCE record_photos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.record_photos_id_seq TO pepepez;


--
-- Name: SEQUENCE record_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.record_seq TO pepepez;


--
-- Name: TABLE records; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.records TO pepepez;


--
-- Name: SEQUENCE records_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.records_id_seq TO pepepez;


--
-- Name: SEQUENCE req_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.req_seq TO pepepez;


--
-- Name: TABLE requirements; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.requirements TO pepepez;


--
-- Name: SEQUENCE requirements_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.requirements_id_seq TO pepepez;


--
-- Name: TABLE suppliers; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.suppliers TO pepepez;


--
-- Name: SEQUENCE suppliers_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.suppliers_id_seq TO pepepez;


--
-- Name: SEQUENCE ticket_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.ticket_seq TO pepepez;


--
-- Name: TABLE tickets; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.tickets TO pepepez;


--
-- Name: SEQUENCE tickets_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.tickets_id_seq TO pepepez;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.users TO pepepez;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.users_id_seq TO pepepez;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO pepepez;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO pepepez;


--
-- PostgreSQL database dump complete
--

\unrestrict GEZCo8hDF597RE4KPs4df0X0ygLSSG9kjcwoAN52eRjpNAt3OAOPNmo0yv6bTuE

